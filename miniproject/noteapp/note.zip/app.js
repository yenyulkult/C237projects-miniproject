const express = require('express');
const app = express();
const mysql = require('mysql2');

const port = 3000;

// Create MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'note'
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database');
});

// Define routes
app.use(express.urlencoded({ extended: true })); // Add this line to parse form data

app.get('/', (req, res) => {
  const sql = 'SELECT * FROM notes';
  connection.query(sql, (error, rows) => {
    if (error) {
      console.error('Error fetching notes:', error);
      res.status(500).send('Error fetching notes');
    } else {
      res.render('index', { notes: rows });
    }
  });
});

app.post('/addnote', (req, res) => {
  const { title, content } = req.body;
  const sql = 'INSERT INTO notes (title, content) VALUES (?,?)';
  connection.query(sql, [title, content], (error, results) => {
    if (error) {
      console.error('Error adding note:', error);
      res.status(500).send('Error adding note');
    } else {
      res.redirect('/');
    }
  });
});

app.post('/edit/:id', (req, res) => {
  const noteId = req.params.id;
  const { content } = req.body;
  const sql = 'UPDATE notes SET content=? WHERE noteId = ?';

  connection.query(sql, [content, noteId], (error, results) => {
    if (error) {
      console.error("Error updating note:", error);
      res.status(500).send('Error updating note');
    } else {
      res.redirect('/');
    }
  });
});

app.get('/delete/:id', (req, res) => {
  const noteId = req.params.id;
  const sql = 'DELETE FROM notes WHERE noteId = ?';
  connection.query(sql, [noteId], (error, results) => {
    if (error) {
      console.error("Error deleting note:", error);
      res.status(500).send('Error deleting note');
    } else {
      res.redirect('/');
    }
  });
});

// Start server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});